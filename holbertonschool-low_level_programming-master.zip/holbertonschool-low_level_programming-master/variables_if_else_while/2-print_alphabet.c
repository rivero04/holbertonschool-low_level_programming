#include <stdio.h>

ear**
 * main - Prints the alphabetic
 *
 * Return:0
 */
int main(void)
{
	char c;

	for (c = 'a'; c <= 'z'; c++)
		putchar(c);

	putchar('\n');
	return (0);
}
