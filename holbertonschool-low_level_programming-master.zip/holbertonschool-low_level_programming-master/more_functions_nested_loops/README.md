no vacio
