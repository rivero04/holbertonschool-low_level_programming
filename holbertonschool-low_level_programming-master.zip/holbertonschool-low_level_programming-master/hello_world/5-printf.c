#include <stdio.h>
/**
  * main - Prints a text
  *
  * Return:0
  */
int main(void)
{
	printf("with proper grammar, but the outcome is a piece of art,\n");
	return (0);
}
