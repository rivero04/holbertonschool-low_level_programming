#ifndef OBJECT_LIKE_MACRO_H
#define OBJECT_LIKE_MACRO_H

/*
 * Desc: Archivo de encabezado que define una macro llamada
 * SIZE como abreviatura del token 1024.
 */

#define SIZE 1024

#endif
