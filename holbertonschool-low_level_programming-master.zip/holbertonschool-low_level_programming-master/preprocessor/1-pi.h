#ifndef PI_H
#define PI_H

/*
 * Desc: Archivo de encabezado que define una macro denominada PI
 * como abreviatura del token 3.14159265359.
 */

#define PI 3.14159265359

#endif
