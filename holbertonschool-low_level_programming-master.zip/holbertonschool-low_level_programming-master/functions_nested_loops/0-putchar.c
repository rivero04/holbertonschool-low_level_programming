#include <stdio.h>
/**
  *main - print _putchar in a new line
  *
  * Return:0
  */
int main(void)
	{
	printf("_putchar\n");
	return (0);
	}
