#ifndef __M_H__
#define __M_H__

#include <stdlib.h>
#include <stdio.h>

void print_school(void);

#endif
